// ══════════════════════════════════════════════
//  API Configuration
// ══════════════════════════════════════════════

export const GEMINI_KEY   = "AIzaSyBzSHj0AaRVIUNDZTBQW85JzjMO3ScgcGs";
export const GOOGLE_KEY   = "AIzaSyCF40gsK_6WFli1Ow8-VfiLpX52Dh89xIk";
export const SEARCH_CX    = "d3557fb81f31c40c2";

export const GEMINI_URL =
  `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_KEY}`;

export const GOOGLE_SEARCH_URL = (query) =>
  `https://www.googleapis.com/customsearch/v1?key=${GOOGLE_KEY}&cx=${SEARCH_CX}&q=${encodeURIComponent(query)}&searchType=image&num=5&safe=active`;
